package vidmot;

public interface Leikhlutur {
    void afarm();
}
